from django.urls import path
from . import views
from blog.views import PostView,post_detail,post_create,post_update,post_delete
urlpatterns=[
	path("",PostView.as_view() ,name="blog_home"),
	path("detail/<int:pk>/",post_detail.as_view(),name="post_detail"),
	path("delete/<int:pk>/",post_delete.as_view(),name="post_delete"),
	path("update/<int:pk>/",post_update.as_view(),name="post_update"),

	path("new/",post_create.as_view(),name="new"),
 	path("about/",views.about,name="blog_about"),
#	path("detail/<int:id>/",views.detail,name='detail'),
#	path("delete/<int:id>/",views.post_delete,name="delete")
]