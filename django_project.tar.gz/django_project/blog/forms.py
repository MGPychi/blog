from django import forms 
from .models import blog_post

class Post_Form(forms.ModelForm):


    class Meta:
        model = blog_post
        fields = ("title","body")