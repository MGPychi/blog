from django.shortcuts import render,redirect
from .models import blog_post
from .forms import Post_Form
from django.utils import timezone
from django.contrib import messages
from .models import blog_post
from django.contrib.auth.mixins import LoginRequiredMixin,UserPassesTestMixin
#from django.contrib.auth.mixins import LoginRequirdMixin

from django.views.generic import ListView,DetailView,CreateView,UpdateView,DeleteView
# Create your views here.

def home(request):
	if request.method=="POST":
		form=Post_Form(request.POST)
		if form.is_valid:
			post = form.save(commit=False)
			post.author = request.user
			post.publish = timezone.now()
			post.save()
			messages.success(request," New post")
			return redirect("blog_home")
	else:
		form = Post_Form()
	posts=blog_post.objects.all()
	context={
	"posts":posts,
	"form":form

	}

	return render(request,"blog/home.html",context)


class PostView(ListView):
	model = blog_post
	template_name="blog/home.html"
	ordering = ["-publish"]
	context_object_name="posts"

class post_detail(DetailView):
	model = blog_post

class post_delete(UserPassesTestMixin,DeleteView):
	model = blog_post
	success_url='/'
	def test_func(self):
		post = self.get_object()
		if self.request.user == post.author:
			return True
		else:
			return False
class post_create(LoginRequiredMixin,CreateView):
	model = blog_post
	fields = ["title","body"]
	def form_valid(self,form):
		form.instance.author=self.request.user
		return super().form_valid(form)

		return redirect("bloge_home")
class post_update(LoginRequiredMixin,UserPassesTestMixin,UpdateView):
	model = blog_post
	fields = ['title',"body"]

	def form_valid(self,form):
		form.instance.author = self.request.user

		return super().form_valid(form) 
	def test_func(self):
		post = self.get_object()
		if self.request.user == post.author:
			return True
		else:
			return False
def about(request):
	return render(request,"blog/about.html")


def detail(request,id):
	post = blog_post.objects.get(id=id)
	content={
		"post":post
	}
	return render(request,"blog/detail.html",content)




def post_deletee(request,id):
	post = blog_post.objects.get(id=id)
	post.delete()
	messages.success(request,"delete ")
	return redirect("blog_home")
