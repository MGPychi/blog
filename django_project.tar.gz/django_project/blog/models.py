from django.db import models
from django.contrib.auth.models import User
from django.urls import reverse
# Create your models here.

class blog_post(models.Model):
    title=models.CharField(max_length=230)

    body=models.TextField()

    publish = models.DateTimeField(auto_now_add=True)

    updates = models.DateTimeField(auto_now=True)

    author = models.ForeignKey(User,on_delete=models.CASCADE)

    class Meta:
        ordering = ('-publish',)

    def __str__(self):
        return self.title

    
    def get_absolute_url(self):
        return reverse("post_detail",kwargs={"pk":self.id})