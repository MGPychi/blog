a=[1,3,4,5]

def g(li):
	k=li[-1]
	li[-1]=int(k)+1
	print(li)



g(a)
